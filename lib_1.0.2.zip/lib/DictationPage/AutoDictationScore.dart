import 'package:dictation_app/DictationPage/OnFinished.dart';
import 'package:dictation_app/Globals/GlobalFunctions.dart';
import 'package:dictation_app/Globals/GlobalParameters.dart';
import 'package:flutter/material.dart';

class AutoDictationScore extends StatefulWidget {

  Dictation dictation;
  //List<Check_word> tested_words = new List<Check_word>();
  //String last_dictation;

  AutoDictationScore(this.dictation);
  @override
  _AutoDictationScoreState createState() => _AutoDictationScoreState();
}

class _AutoDictationScoreState extends State<AutoDictationScore>{
  List<Check_word> user_results = new List<Check_word>();
  List<Color> cards_colors = new List<Color>();

  @override
  Widget build(BuildContext context) {
    add_default_colors();
    return Scaffold(
      appBar: AppBar(
        title: Text("Grade your score"),
      ),
      body: Column(
        children: <Widget>[
          ListView.builder(
              physics: NeverScrollableScrollPhysics(),
              //scrollDirection: Axis.vertical,
              shrinkWrap: true,
              itemCount: widget.dictation.words_list.length,
              itemBuilder: (BuildContext context, int index) =>
                  ResultCard(context, index)),
          Padding(
            padding: const EdgeInsets.all(12.0),
            child: custom_button(Row(
              children: <Widget>[
                Text(
                  "Submit",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      fontSize: 17,
                      color: Colors.white
                  ),
                ),
              ],
              mainAxisAlignment: MainAxisAlignment.center,
            ), finished, Colors.blue[800], Colors.blue[400]),
          )
        ],
      ),
    );
  }
  void add_default_colors()
  {
    bool start = true;
    cards_colors.forEach((cell){
      if (cell != Colors.grey)
        {
          start = false;
        }
    });
    if (start == true)
      {
        cards_colors.clear();
        widget.dictation.words_list.forEach((cell){
          cards_colors.add(Colors.grey);
        });
      }

  }
  void finished()
  {
    widget.dictation.last_dictation_tested_words = user_results;
    GlobalParameters.last_dictation = widget.dictation;
    //GlobalParameters.last_saved_dictation = widget.dictation;
    Navigator.pop(context);
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) {
          return OnFinished(widget.dictation,user_results,"check");
        },
      ),
    );
  }
  Widget ResultCard(BuildContext context,int index)
  {

    return Column(
      children: <Widget>[
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: <Widget>[
            FloatingActionButton(
              heroTag: "${widget.dictation.words_list[index].word} word",
              backgroundColor: floating_action_button_color(true,index),
              child: Icon(Icons.check),
              onPressed: (){
                Check_word word_to_add = Check_word(widget.dictation.words_list[index].translation,widget.dictation.words_list[index].word,"word");
                check_if_exists(index);
                user_results.add(word_to_add);
                setState(() {
                  cards_colors[index] = Colors.green;
                });
                },
            ),
            Card(

              shape: RoundedRectangleBorder(
                side: new BorderSide(
                    color: cards_colors[index],
                    width: 4.0),
                borderRadius: BorderRadius.circular(15.0),
              ),
              child: Column(
                children: <Widget>[
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: <Widget>[
                      Column(
                        children: <Widget>[
                          Padding(
                            padding: const EdgeInsets.all(15.0),
                            child: Text("Word",style: TextStyle(
                                fontSize: 25
                            ),),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Text(widget.dictation.words_list[index].word,style: TextStyle(
                                fontSize: 25
                            ),),
                          )
                        ],
                      ),
                      Column(
                        children: <Widget>[
                          Padding(
                            padding: const EdgeInsets.all(15.0),
                            child: Text("Translation",style: TextStyle(
                              fontSize: 25
                            ),),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Text(widget.dictation.words_list[index].translation,style: TextStyle(
                                fontSize: 25
                            ),),
                          )
                        ],
                      ),
                    ],
                  )
                ],
              ),
              //color: check_if_correct(widget.tested_words[index]),
            ),
            FloatingActionButton(
              heroTag: "${widget.dictation.words_list[index].translation} translation",
              backgroundColor: floating_action_button_color(false,index),
              child: Icon(Icons.clear),
              onPressed: (){
                Check_word word_to_add = Check_word("",widget.dictation.words_list[index].word,"word");
                check_if_exists(index);
                user_results.add(word_to_add);
                setState(() {
                  cards_colors[index] = Colors.redAccent;
                });
              },
            ),
            //
          ],
        ),
        Divider(endIndent: 10,indent: 10,color: Colors.grey,)
      ],
    );
  }
  Color floating_action_button_color(bool correct,int index)
  {
    if (cards_colors[index] == Colors.redAccent)
      {
        if (correct == false)
          {
            return Colors.redAccent;
          }
      }
    else if (cards_colors[index] == Colors.green)
    {
      if (correct == true)
      {
        return Colors.green;
      }
    }
    return Colors.grey;
  }
  void check_if_exists(int index)
  {
    for (int i = 0; i < user_results.length;i ++) {
      if (user_results[i].shown_word ==
          widget.dictation.words_list[index].word) {
        user_results.remove(user_results[i]);
      }
    }
  }
}