import 'dart:ffi';

import 'package:dictation_app/DictationPage/DictationQuiz.dart';
import 'package:dictation_app/Globals/GlobalParameters.dart';
import 'package:dictation_app/Globals/constant.dart';
import 'package:dictation_app/SaveInFile.dart';
import 'package:dictation_app/Widgets/CircleProgress.dart';
import 'package:dictation_app/Widgets/my_header.dart';
import 'package:flutter/material.dart';

class OnFinished extends StatefulWidget {

  Dictation dictation;
  List<Check_word> tested_words = new List<Check_word>();
  String last_dictation;

  OnFinished(this.dictation,this.tested_words,this.last_dictation);
  @override
  _OnFinishedState createState() => _OnFinishedState();
}

class _OnFinishedState extends State<OnFinished> with SingleTickerProviderStateMixin{
  //grade animation
  AnimationController progressController;
  Animation<double> animation;
  //
  List<String> words = new List<String>();
  List<Word> wrong_words = new List<Word>();
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  String correct_word;
  bool correct;
  bool add_to_wrong_words = true;
  int wrong_counter = 0;
  double user_grade = 0;
  int words_counter = 0;

  void initState(){
    super.initState();
    progressController = AnimationController(vsync: this,duration: Duration(milliseconds: 1000));
    animation = Tween<double>(begin: 0,end: user_grade).animate(progressController)..addListener((){
      setState(() {

      });
    });
    GlobalParameters.correct_counter = 0;


  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      body: Column(
        children: <Widget>[
          MyHeader(
            textTop: Positioned(
              //top: 10,
              //left: 100,
              child: Text(
                "Quiz - ${widget.dictation.name}\n",
                style: kHeadingTextStyle.copyWith(
                    color: Colors.white,
                    fontSize: 50,
                    fontStyle: FontStyle.italic
                ),
              ),
            ),
            textBottom: Positioned(
              //top: 10,
              //left: 50,
              child: Text(
                "\n\n${GlobalParameters.correct_counter} out of ${widget.dictation.words_list.length} are correct",
                style: kHeadingTextStyle.copyWith(
                    color: Colors.white,
                    fontSize: 25,
                    fontStyle: FontStyle.italic
                ),
              ),
            ),
            offset: 2,
            height: 250,
            left_height: 30,
            right_height: 100,
            color_1: Colors.orange,
            color_2: Colors.redAccent,
            left_widget: close_dictation(),
            right_widget: Container(),
          ),
          Center(
            child: CustomPaint(
              foregroundPainter: CircleProgress(animation.value), // this will add custom painter after child
              child: Container(
                width: 100,
                height: 100,
                child: GestureDetector(
//                    onTap: (){
//                      if(animation.value == 80){
//                        progressController.reverse();
//                      }else {
//                        progressController.forward();
//                      }
//                    },
                    child: Center(child: Text("${animation.value.toInt()}%",style: TextStyle(
                        fontSize: 30,
                        fontWeight: FontWeight.bold
                    ),))),
              ),
            ),

          ),
          DataTable(
            columns: <DataColumn>[

              DataColumn(
                label:
                Text(
                  'Word',
                  style: TextStyle(
                      fontStyle: FontStyle
                          .italic),
                ),
              ),
              DataColumn(
                label: Text(
                  'User input',
                  style: TextStyle(
                      fontStyle: FontStyle
                          .italic),
                ),
              ),
              DataColumn(
                label: Text(
                  'Check',
                  style: TextStyle(
                      fontStyle: FontStyle
                          .italic),
                ),
              ),
            ],
            rows:
             // Loops through dataColumnText, each iteration assigning the value to element
                widget.tested_words.map(
              ((element) => DataRow(
                cells: <DataCell>[
                  //DataCell(Text(element["Name"])), //Extracting from Map element the value
                  DataCell(Text(element.shown_word,style: TextStyle(
                    fontSize: 20
                  ),),
                  ),
                  DataCell(check_user_input(element)),
                  DataCell(correct_or_not_icon(element)),
                ],
              )),
            ).toList(),
          ),
          wrong_words.length != 0 ? Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: <Widget>[
                custom_button("Practice on the wrong words",quiz_on_the_wrong_words),
                custom_button("Quiz again",quiz_again,Icon(Icons.refresh)),
              ],
            ),
          ): Row(
            mainAxisAlignment:  MainAxisAlignment.spaceAround,
            children: <Widget>[
              Container(),
              Padding(
                padding: const EdgeInsets.all(20.0),
                child: custom_button("Quiz again",quiz_again,Icon(Icons.refresh)),
              ),
              Container(),
            ],
          ),

        ],
      ),
    );
  }
  void quiz_again()
  {
    GlobalParameters.tested_words_count = 0;
    widget.tested_words.clear();
    Navigator.pop(context);
    Navigator.pop(context);
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) {
          return DictationQuiz(widget.dictation);
        },
      ),
    );
  }
  void quiz_on_the_wrong_words()
  {
//    Dictation dictation;
//    String name = "${widget.dictation.name} - Practice words";
    widget.dictation.last_wrong_words = wrong_words;

    String name = "Practice";
    Dictation wrong_words_dictation = Dictation(name,widget.dictation.last_wrong_words,widget.dictation.say_word,widget.dictation.test_type,
    widget.dictation.duration,widget.dictation.last_wrong_words,widget.dictation.date,widget.tested_words);
    GlobalParameters.tested_words_count = 0;
    widget.tested_words.clear();
    add_to_wrong_words = false;
    SaveInFile.save_in_file();
    Navigator.pop(context);
    Navigator.pop(context);
    //Navigator.pop(context);
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) {
          return DictationQuiz(wrong_words_dictation);
        },
      ),
    );
//    dictation.words_list = wrong_words;
//    dictation.say_word = false;
//    dictation.duration = 6;
    //dictation.test_type = "Quiz only on the translations";
    //GlobalParameters.Dictations.add(Dictation(name,wrong_words,false,"Quiz only on the translations",6));
//    GlobalParameters.snackBarValue = "Dictation has been added";
//    _scaffoldKey.currentState.showSnackBar(GlobalParameters.snackBar);
  }
  Widget correct_or_not_icon(Check_word check_word)
  {

    double every_word_points;
    Widget returned_widget;
    if(correct == true)
    {
      setState(() {
        GlobalParameters.correct_counter++;
      });
      returned_widget = Icon(Icons.check,color: Colors.green,size: 30,);
    }
    else
    {
      wrong_counter ++;
      returned_widget = Row(
        children: <Widget>[
          Icon(Icons.clear,color: Colors.redAccent,size: 30,),
          IconButton(
            icon: Icon(Icons.arrow_forward_ios),
            onPressed: (){
              showDialog(
                  context: context,
                  builder: (BuildContext context){
                    return StatefulBuilder(
                      builder: (context, setState)
                      {
                        return AlertDialog(
                            shape: new RoundedRectangleBorder(
                              borderRadius: new BorderRadius.circular(20),
                            ),
                            title: Container(
                                child: Row(
                                  children: <Widget>[
                                    Text("Word - ${check_word.shown_word}",style: TextStyle(fontSize: 25,fontWeight: FontWeight.bold),),
                                  ],
                                )
                            ),
                            content: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: <Widget>[
                                Padding(
                                  padding: const EdgeInsets.fromLTRB(0,0,0,10),
                                  child: Text("User input: ${check_word.translation}",style: TextStyle(
                                      fontSize: 20
                                  ),),
                                ),
                                Divider(),
                                Padding(
                                  padding: const EdgeInsets.fromLTRB(0,0,0,10),
                                  child: show_correct_word(check_word),
                                ),

                              ],
                            )
                        );
                      },
                    );
                  }
              );
            },
          )
//          Text("Answer: ${correct_word}",style: TextStyle(
//            fontSize: 17
//          ),)
        ],
      );
    }
    words_counter ++;
    if (words_counter == widget.dictation.words_list.length)
    {
      every_word_points = 100/words_counter;
      setState(() {
        //every_word_points.round();
        user_grade = every_word_points*GlobalParameters.correct_counter;

        //user_grade.double.parse(num1.toStringAsFixed(2));
        //user_grade.toDouble();
        //assign_func();
        user_grade = double.parse(user_grade.toStringAsFixed(0));

        if ((user_grade != 0) && (user_grade.round() == user_grade))
        {
          animation = Tween<double>(begin: 0,end: user_grade).animate(progressController)..addListener((){});
          progressController.forward();
        }

      });

    }
    return returned_widget;
  }
  Widget show_correct_word(Check_word check_word)
  {
//    int index = words.indexOf(check_word.shown_word);
//    if (index == -1)
//      {
//        return Text("Correct answer:",style: TextStyle(
//          fontSize: 20,
//        ),);
//      }
    for (int i = 0;i < widget.dictation.words_list.length;i ++)
      {
        if (widget.dictation.words_list[i].word == check_word.shown_word)
          {
            return Text("Correct answer: ${widget.dictation.words_list[i].translation}",style: TextStyle(
              fontSize: 20,
            ),);
          }
      }
    return Text("Correct answer:",style: TextStyle(
      fontSize: 20,
    ),);
//    return Text("Correct answer: ${widget.dictation.words_list[index].translation}",style: TextStyle(
//      fontSize: 20,
//    ),);
  }
  Widget close_dictation()
  {

    return IconButton(
      icon: Icon(Icons.clear,size: 40,color: Colors.white,),
      onPressed: (){

        if (widget.last_dictation == "check")
          {
            widget.tested_words.forEach((cell) {
              GlobalParameters.last_dictation_tested_words.add(cell);
            });
            //GlobalParameters.last_dictation_tested_words = widget.tested_words;
            //_controller.clear();
            //GlobalParameters.last_saved_dictation.last_dictation_tested_words = widget.tested_words;
            //widget.dictation.last_dictation_tested_words.clear();
            widget.tested_words.forEach((cell)
            {
              GlobalParameters.last_saved_dictation.last_dictation_tested_words.add(cell);
              //widget.dictation.last_dictation_tested_words.add(cell);
            });
            print("finished recent: ${GlobalParameters.recentDictations.length.toString()}");
//            if (GlobalParameters.recentDictations.length < GlobalParameters.recent_dictations_length)
//            {
//              GlobalParameters.recentDictations.add(widget.dictation);
//            }
            //SaveInFile.save_recent_dictations();
            SaveInFile.save_last_dictation();
            GlobalParameters.tested_words_count = 0;
            GlobalParameters.tested_words.clear();
            //submit_button_text = "Submit";
            Navigator.pop(context);
            Navigator.pop(context);
            Navigator.pop(context);
          }
        else
          {

            Navigator.pop(context);
          }

      },
    );
  }
  Widget check_user_input(Check_word filled_word)
  {
    String user_text;
    Color correct_or_not;
    //wrong_words.clear();
    switch(filled_word.type)
        {
      case "word":
        {
          for (int i = 0;i < widget.dictation.words_list.length;i ++)
          {

            if (widget.dictation.words_list[i].word.toLowerCase() == filled_word.shown_word.toLowerCase())
            {
              String filled_word_translation = remove_decoration(filled_word.translation);
              String real_translation = remove_decoration(widget.dictation.words_list[i].translation);
              if (filled_word_translation == real_translation)
              {
                user_text = filled_word_translation;
                correct_or_not = Colors.green[300];
                words.add(widget.dictation.words_list[i].word);
                //GlobalParameters.correct_counter++;
                correct = true;
              }
              else{
                user_text = filled_word_translation;
                correct_or_not = Colors.red[300];
                //correct_word = widget.dictation.words_list[i].translation;
                words.add(widget.dictation.words_list[i].word);
                bool already_exist = false;
                if (add_to_wrong_words == true)
                  {
                    for (int i = 0;i < wrong_words.length;i ++)
                      {
                        for (int j = 0;j < widget.dictation.words_list.length;j ++)
                          {
                            if (wrong_words[i] == Word(widget.dictation.words_list[j].word,widget.dictation.words_list[j].translation))
                            {
                              already_exist = true;
                            }
                          }

                      }
                    if (already_exist == false)
                      {
                        wrong_words.add(Word(widget.dictation.words_list[i].word,widget.dictation.words_list[i].translation));
                      }

                  }

                correct = false;
              }
              break;
            }
            else if (filled_word.shown_word == "")
              {
                correct = false;
              }

          }


//          for (int i = 0;i < widget.dictation.words_list.length;i ++)
//          {
//            if (widget.dictation.words_list[i].translation.toLowerCase() == filled_word.translation.toLowerCase())
//              {
//                if (filled_word.shown_word.toLowerCase() == widget.dictation.words_list[i].word.toLowerCase())
//                {
//                  user_text = filled_word.shown_word;
//                  correct_or_not = Colors.green[300];
//                }
//                else{
//                  user_text = filled_word.shown_word;
//                  correct_or_not = Colors.red[300];
//                }
//                break;
//              }
//            else
//              {
//                user_text = filled_word.translation;
//                correct_or_not = Colors.red[300];
//              }
//          }
        }
        break;
      case "translation":
        {
          for (int i = 0;i < widget.dictation.words_list.length;i ++)
          {
            if (widget.dictation.words_list[i].translation.toLowerCase() == filled_word.shown_word.toLowerCase())
            {
              if (filled_word.translation.toLowerCase() == widget.dictation.words_list[i].word.toLowerCase())
                {
                  user_text = filled_word.translation;
                  correct_or_not = Colors.green[300];
                  //GlobalParameters.correct_counter++;
                  correct = true;
                }
              else{
                user_text = filled_word.translation;
                correct_or_not = Colors.red[300];
                //wrong_words.add(Word(widget.dictation.words_list[i].word,widget.dictation.words_list[i].translation));

                words.add(widget.dictation.words_list[i].word);
                bool already_exist = false;
                if (add_to_wrong_words == true)
                {
                  for (int i = 0;i < wrong_words.length;i ++)
                  {
                    for (int j = 0;j < widget.dictation.words_list.length;j ++)
                    {
                      if (wrong_words[i] == Word(widget.dictation.words_list[j].word,widget.dictation.words_list[j].translation))
                      {
                        already_exist = true;
                      }
                    }

                  }
                  if (already_exist == false)
                  {
                    wrong_words.add(Word(widget.dictation.words_list[i].word,widget.dictation.words_list[i].translation));
                  }

                }
                correct = false;
              }
              break;
            }
            else if (filled_word.shown_word == "")
            {
              correct = false;
            }
          }
        }
        break;
    }
    return Text(user_text,style: TextStyle(
      fontSize: 20,
      //backgroundColor: correct_or_not,
    ),);
  }
  String remove_decoration(String translated_word)
  {
    List<String> hebrew_letters = new List<String>();
    hebrew_letters.add("א");
    hebrew_letters.add("ב");
    hebrew_letters.add("ג");
    hebrew_letters.add("ד");
    hebrew_letters.add("ה");
    hebrew_letters.add("ו");
    hebrew_letters.add("ז");
    hebrew_letters.add("ח");
    hebrew_letters.add("ט");
    hebrew_letters.add("י");
    hebrew_letters.add("כ");
    hebrew_letters.add("ל");
    hebrew_letters.add("מ");
    hebrew_letters.add("נ");
    hebrew_letters.add("ס");
    hebrew_letters.add("ע");
    hebrew_letters.add("פ");
    hebrew_letters.add("צ");
    hebrew_letters.add("ק");
    hebrew_letters.add("ר");
    hebrew_letters.add("ש");
    hebrew_letters.add("ת");
    hebrew_letters.add("ך");
    hebrew_letters.add("ף");
    hebrew_letters.add("ץ");
    hebrew_letters.add("ן");
    String fixed_word = "";
    for (int i = 0;i < translated_word.length;i ++)
    {
      String a = translated_word[i];
      if (hebrew_letters.contains(a))
      {
        fixed_word += a;
      }
      print(a);
    }
    return fixed_word;
    //print(fixed_word);
  }
  Widget custom_button(String text,Function on_pressed,[Widget icon])
  {
    return RaisedButton(
      onPressed: () {
        on_pressed();
      },
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(80.0)),
      padding: const EdgeInsets.all(0.0),
      child: Container(
        decoration: BoxDecoration(
          gradient:  LinearGradient(
            colors: <Color>[
              (Colors.orange[300]),
              Colors.orange,
              //Color(0xFF1976D2),
              //kInfectedColor,
            ],
          ),
          borderRadius: BorderRadius.all(Radius.circular(80.0)),
        ),
        child: Container(
          constraints: const BoxConstraints(minWidth: 88.0, minHeight: 36.0), // min sizes for Material buttons
          alignment: Alignment.center,
          child: Row(
            children: <Widget>[
              icon != null ? icon : SizedBox.shrink(),
              Padding(
                padding: const EdgeInsets.all(12.0),
                child: Text(
                  text,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      fontSize: 17,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}