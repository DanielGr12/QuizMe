import 'package:dictation_app/file_write.dart';
import 'package:flutter/material.dart';
class GlobalParameters
{

  static List<Dictation> Dictations = new List<Dictation>();
  static Dictation add_dictation = new Dictation("", words_to_add_list, false, "Show the word in your language",6,last_dictation_worng_words,"",clear_tested_words_list);
  static List<Word> words_to_add_list = new List<Word>();
  static List<Word> last_dictation_worng_words = new List<Word>();
  static List<Check_word> clear_tested_words_list = new List<Check_word>();
  static List<Dictation> recentDictations = new List<Dictation>();
  static int recent_dictations_length = 5;

  static List<Check_word> tested_words_list = new List<Check_word>();
  static List<Map<String, String>> words_to_add_list_dictionary = new List<Map<String, String>>();
  //static Dictation add_words;
  static List<DropdownMenuItem<String>> languages_list = new List<DropdownMenuItem<String>>();
  static String selected_dictation = "Select dictation";
  static TabController tab_controller;
  static int tested_words_count = 0;
  static List<Check_word> tested_words = new List<Check_word>();
  static int correct_counter = 0;
  static String last_dictation_date;
  static Dictation last_dictation;
  static LastDictation last_saved_dictation;
  static List<Check_word> last_dictation_tested_words = new List<Check_word>();
  static String snackBarValue;
  static var snackBar = SnackBar(content: Text(snackBarValue));
  static var now = DateTime(
      DateTime.now().year,
      DateTime.now().month,
      DateTime.now().day
  );
  static String current_shown_word;
  static int said_word_counter = 0;

}
class LastDictation
{
  String name;
  List<Word> words_list = new List<Word>();
  bool say_word = false;
  String test_type;
  String from_language;
  String to_language;
  int duration = 6;
  String date;
  List<Check_word> last_dictation_tested_words = new List<Check_word>();

  LastDictation(this.name,this.words_list,this.say_word,this.test_type,this.date,this.last_dictation_tested_words,this.duration,[this.from_language,this.to_language]);

  Map<String, dynamic> toJson() => {
    'name': name,
    'words_list': words_list,
    'say_word': say_word,
    'test_type': test_type,
    'duration': duration,
    'from_language': from_language,
    'to_language': to_language,
    'date': date,
    'last_dictation_tested_words': last_dictation_tested_words,

  };
}
class TestedWord
{
  Word word;
  bool correct;
  TestedWord(this.word,this.correct);
  Map<String, dynamic> toJson() => {
    "word": word,
    "correct": correct,
  };
}
class Dictation
{
  String name;
  List<Word> words_list = new List<Word>();
  bool say_word = false;
  String test_type;
  String from_language;
  String to_language;
  int duration = 6;
  List<Word> last_wrong_words = new List<Word>();
  String date;
  List<Check_word> last_dictation_tested_words = new List<Check_word>();
  String last_dictation_time;
  Dictation(this.name,this.words_list,this.say_word,this.test_type,this.duration,this.last_wrong_words,this.date,this.last_dictation_tested_words,[this.from_language,this.to_language,this.last_dictation_time]);

  Map<String, dynamic> toJson() => {
    'name': name,
    'words_list': words_list,
    'say_word': say_word,
    'test_type': test_type,
    "duration": duration,
    'from_language': from_language,
    'to_language': to_language,
    'last_wrong_words' : last_wrong_words,
    "date": date,
    "last_tested_words": last_dictation_tested_words,
    "last_dictation_time" : last_dictation_time,
  };

}
class Check_word
{
  String shown_word;
  String translation;
  String type;
  Check_word(this.translation,this.shown_word,this.type);
  Map<String, dynamic> toJson() => {
    'shown_word': shown_word,
    'translation': translation,
    'type': type,
  };
}
class Word
{
  String word;
  String translation;
  Word(this.word,this.translation);

  Map<String, dynamic> toJson() => {
    'word': word,
    'translation': translation,
  };
}