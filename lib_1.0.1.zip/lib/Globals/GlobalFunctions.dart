import 'package:dictation_app/Globals/GlobalParameters.dart';
import 'package:dictation_app/Globals/constant.dart';
import 'package:dictation_app/SaveInFile.dart';
import 'package:flutter/material.dart';

Widget custom_button(Widget buttonChild,Function on_pressed,Color firstColor,Color secondColor)
{
  return RaisedButton(
    onPressed: () {
      on_pressed();
    },
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(80.0)),
    padding: const EdgeInsets.all(0.0),
    child: Container(
      decoration: BoxDecoration(
        gradient:  LinearGradient(
          colors: <Color>[
            firstColor,
            secondColor,
          ],
        ),
        borderRadius: BorderRadius.all(Radius.circular(80.0)),
      ),
      child: Container(
        constraints: const BoxConstraints(minWidth: 88.0, minHeight: 36.0),
          child: buttonChild,

      ),
//      Container(
//        constraints: const BoxConstraints(minWidth: 88.0, minHeight: 36.0), // min sizes for Material buttons
//        alignment: Alignment.center,
//        child: Text(
//          text,
//          textAlign: TextAlign.center,
//          style: TextStyle(
//              fontSize: 17
//          ),
//        ),
//      ),
    ),
  );
}
