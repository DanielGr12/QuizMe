//import 'dart:html';

import 'package:dictation_app/Globals/GlobalParameters.dart';
import 'package:dictation_app/Globals/constant.dart';
import 'package:dictation_app/SaveInFile.dart';
import 'package:dictation_app/Widgets/my_header.dart';
import 'package:flutter/material.dart';
import 'package:translator/translator.dart';
class NewDictation extends StatefulWidget {
  @override
  _NewDictationState createState() => _NewDictationState();
}

class _NewDictationState extends State<NewDictation> {
  String translation_word;
  var translation_field_val = TextEditingController();

  //Dictation dictation = new Dictation("", dictation_words, false, "Show the word in your language",6,last_dictation_worng_words,"",clear_tested_words_list);
  List<Word> dictation_words = new List<Word>();
  List<Word> last_dictation_worng_words = new List<Word>();
  List<Check_word> clear_tested_words_list = new List<Check_word>();
  //Dictation dictation;

  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  String word;
  String name;
  var _controller = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        key: _scaffoldKey,
        backgroundColor: Colors.white,
        body: SingleChildScrollView(
          child: Container(
            child: Column(
              children: <Widget>[
                title(),
              Padding(
                padding: const EdgeInsets.fromLTRB(20,0,20,15),
                child: TextFormField(
                  controller: _controller,
                  decoration: InputDecoration(
                    labelText: "Name",
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                    suffixIcon: IconButton(
                      onPressed: () {
                        name = "";
                        _controller.clear();
                      },
                      icon: Icon(Icons.clear),
                    ),
                  ),
                  onFieldSubmitted: (String dictation_name){
                    name = dictation_name;
                  },

                ),
              ),

                Container(
                  margin: EdgeInsets.symmetric(horizontal: 20),
                  padding: EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                  height: 250,
                  width: double.infinity,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(25),
                    border: Border.all(
                      color: Colors.grey[500],
                    ),
                  ),
                  child: Column(
                    children: <Widget>[
                      Row(
                        children: <Widget>[
                          Padding(
                            padding: EdgeInsets.fromLTRB(25, 10, 4, 20),
                            child: Text("Words", style: TextStyle(
                                fontSize: 20
                            ),),
                          ),
                          Spacer(),
                          IconButton(
                              icon: Icon(Icons.add),
                            onPressed: (){
                              showDialog(
                                  context: context,
                                  builder: (BuildContext context){
                                    return StatefulBuilder(
                                      builder: (context, setState)
                                      {
                                        return AlertDialog(
                                            shape: new RoundedRectangleBorder(
                                              borderRadius: new BorderRadius.circular(20),
                                            ),
                                            title: Container(
                                                child: Row(
                                                  children: <Widget>[
                                                    Text("Add word",style: TextStyle(fontSize: 25,fontWeight: FontWeight.bold),),
                                                  ],
                                                )
                                            ),
                                            content: Column(
                                              mainAxisSize: MainAxisSize.min,
                                              children: <Widget>[
                                                Padding(
                                                  padding: const EdgeInsets.fromLTRB(0,0,0,10),
                                                  child: TextFormField(
                                                    decoration: InputDecoration(
                                                      labelText: "Word",
                                                      border: OutlineInputBorder(
                                                        borderRadius: BorderRadius.circular(16),
                                                      ),
                                                    ),
                                                    onChanged: (String val){
                                                      word = val;
                                                    },
                                                  ),
                                                ),
                                                Container(
                                                  child: TextFormField(
                                                    decoration: InputDecoration(
                                                      labelText: "Translation",
                                                      border: OutlineInputBorder(
                                                        borderRadius: BorderRadius.circular(16),
                                                      ),
                                                    ),
                                                    onChanged: (String val){
                                                      translation_word = val;
                                                    },
                                                    controller: translation_field_val,
                                                  ),
                                                ),
                                                custom_button("Auto fill", auto_fill),
                                                custom_button("Add", add_word),

                                              ],
                                            )
                                        );
                                      },
                                    );
                                  }
                              );
                            },
                          ),
                        ],
                      ),
                      Expanded(
                        child: Container(
                          child: WordsListCard(),
                        )

                      ),//: SizedBox.shrink(),
                    ],
                  ),
                ),
                Padding(
                  child: custom_button("Add dictation", add_dictation),
                  padding: EdgeInsets.all(15),
                ),
                Padding(
                  padding: EdgeInsets.all(15),
                ),
              ],
            ),
          ),
        )
    );
  }
  Widget WordsListCard()
  {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        //flex: 1,
        children: <Widget>[
          DataTable(
            columns: <DataColumn>[
              DataColumn(
                label:
                Text(
                  'Word',
                  style: TextStyle(
                      fontStyle: FontStyle.italic,
                      fontSize: 15
                  ),
                ),
              ),
              DataColumn(
                label: Text(
                  'Translation',
                  style: TextStyle(
                      fontStyle: FontStyle.italic,
                      fontSize: 15
                  ),
                ),
              ),
            ],
            rows: List.generate(
                dictation_words.length, (index) => dataRow(dictation_words[index])),
          ),
        ],
      ),
    );
  }
  DataRow dataRow(Word cell)
  {
    return DataRow(
      cells: <DataCell>[
        //DataCell(Text(element["Name"])), //Extracting from Map element the value
        DataCell(Text(cell.word,style: TextStyle(
          fontSize: 15
        ),)),
        DataCell(Row(
          children: <Widget>[
            Text(cell.translation, style: TextStyle(fontSize: 15),),
            Spacer(),
            IconButton(
              icon: Icon(Icons.remove),
              onPressed: () {
                setState(() {
                  GlobalParameters.words_to_add_list.remove(cell);
                });
              },
            )
          ],
        )),
      ],
    );
  }
  void add_dictation()
  {

    if ((name != null) && (name != ""))
      {
        GlobalParameters.Dictations.forEach((cell){
          if (cell.name == name)
          {
            GlobalParameters.snackBarValue = "This dictation name is used in another dictation";
            _scaffoldKey.currentState.showSnackBar(GlobalParameters.snackBar);
            setState(() {
              _controller.clear();
              name = "";
            });
          }
        });
        if (name != "")
          {
            //GlobalParameters.add_dictation.name = name;
            if (dictation_words.length != 0)
            {
//              List<Dictation> not_updated_dictations = new List<Dictation>();
//              GlobalParameters.Dictations.forEach((cell){
//                not_updated_dictations.add(cell);
//              });
//              GlobalParameters.Dictations.clear();
//              GlobalParameters.Dictations.add(GlobalParameters.add_dictation);
//              not_updated_dictations.forEach((cell){
//                GlobalParameters.Dictations.add(cell);
//              });
              //int dictation_index = GlobalParameters.Dictations.indexOf(GlobalParameters.add_dictation);
//            GlobalParameters.Dictations[dictation_index].words_list.clear();
//            for (int i = 0; i < GlobalParameters.words_to_add_list.length;i ++)
//              {
//                GlobalParameters.Dictations[dictation_index].words_list.add(GlobalParameters.words_to_add_list[i]);
//              }
              List<Dictation> not_updated_dictations = new List<Dictation>();
              GlobalParameters.Dictations.forEach((cell){
                not_updated_dictations.add(cell);
              });
              GlobalParameters.Dictations.clear();
              Dictation dictation = new Dictation(name, dictation_words, false, "Show the word in your language",6,last_dictation_worng_words,"",clear_tested_words_list);
              GlobalParameters.Dictations.add(dictation);
              not_updated_dictations.forEach((cell){
                GlobalParameters.Dictations.add(cell);
              });
              SaveInFile.save_in_file();
              Navigator.pop(context);
          }

            //name = "";

            //GlobalParameters.add_dictation.words_list.clear();
          }
        else
          {
            GlobalParameters.snackBarValue = "Add words to the dictation";
            _scaffoldKey.currentState.showSnackBar(GlobalParameters.snackBar);
          }
      }
    else{
      GlobalParameters.snackBarValue = "Fill the dictation name";
      _scaffoldKey.currentState.showSnackBar(GlobalParameters.snackBar);
    }
  }
  void auto_fill()
  {
    if (word == null)
      {
        GlobalParameters.snackBarValue = "First add word";
        _scaffoldKey.currentState.showSnackBar(GlobalParameters.snackBar);
        Scaffold.of(context).showSnackBar(GlobalParameters.snackBar);
      }
    else if (word != null)
    {
      final translator = GoogleTranslator();
      translator.translate(word, from: 'en', to: 'iw').then((translated_word) {
        setState(() {
          translation_word = translated_word;
          //translation_word = translated_word;
          translation_field_val.text = translation_word;

          //String a = translated_word.
          //print(a);
        });
        //add_word();
      });
    }
    else if((word == null) && (translation_word == null))
      {
        GlobalParameters.snackBarValue = "First add word";
        Scaffold.of(context).showSnackBar(GlobalParameters.snackBar);
      }
  }
  String remove_decoration(String translated_word)
  {
    List<String> hebrew_letters = new List<String>();
    hebrew_letters.add("א");
    hebrew_letters.add("ב");
    hebrew_letters.add("ג");
    hebrew_letters.add("ד");
    hebrew_letters.add("ה");
    hebrew_letters.add("ו");
    hebrew_letters.add("ז");
    hebrew_letters.add("ח");
    hebrew_letters.add("ט");
    hebrew_letters.add("י");
    hebrew_letters.add("כ");
    hebrew_letters.add("ל");
    hebrew_letters.add("מ");
    hebrew_letters.add("נ");
    hebrew_letters.add("ס");
    hebrew_letters.add("ע");
    hebrew_letters.add("פ");
    hebrew_letters.add("צ");
    hebrew_letters.add("ק");
    hebrew_letters.add("ר");
    hebrew_letters.add("ש");
    hebrew_letters.add("ת");
    hebrew_letters.add("ך");
    hebrew_letters.add("ף");
    hebrew_letters.add("ץ");
    hebrew_letters.add("ן");
    String fixed_word = "";
    for (int i = 0;i < translated_word.length;i ++)
      {
        String a = translated_word[i];
        if (hebrew_letters.contains(a))
          {
            fixed_word += a;
          }
        print(a);
      }
    return fixed_word;
      //print(fixed_word);
  }
  void add_word()
  {
      if (word != null)
        {
          if (translation_word != null)
            {
              setState(() {
                translation_field_val.text = "";
                dictation_words.add(Word(word,translation_word));
                //GlobalParameters.words_to_add_list.add(Word(word,translation_word));
                //GlobalParameters.add_dictation.words_list.add(Word(word,translation_word));
                word = null;
                translation_word = null;
                Navigator.pop(context);
              });

            }
        }
      else{
        GlobalParameters.snackBarValue = "First add word";
        _scaffoldKey.currentState.showSnackBar(GlobalParameters.snackBar);
        Scaffold.of(context).showSnackBar(GlobalParameters.snackBar);
      }
  }
  Widget custom_button(String text,Function on_pressed)
  {
    return RaisedButton(
      onPressed: () {
        on_pressed();
      },
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(80.0)),
      padding: const EdgeInsets.all(0.0),
      child: Container(
        decoration: BoxDecoration(
          gradient:  LinearGradient(
            colors: <Color>[
              (Colors.lightBlue[300]),
              Colors.blue,
              //Color(0xFF1976D2),
              //kInfectedColor,
            ],
          ),
          borderRadius: BorderRadius.all(Radius.circular(80.0)),
        ),
        child: Container(
          constraints: const BoxConstraints(minWidth: 88.0, minHeight: 36.0), // min sizes for Material buttons
          alignment: Alignment.center,
          child: Text(
            text,
            textAlign: TextAlign.center,
            style: TextStyle(
                fontSize: 17
            ),
          ),
        ),
      ),
    );
  }
//  static void word_submitted(String val)
//  {
//    GlobalParameters.add_words.words_list.add(Word(val));
//  }
//  static void translation_submitted(String val)
//  {
//    GlobalParameters.add_words.words_list.add(Word(val));
//  }
  Widget buildWordCard(BuildContext context, int index)
  {
    return Column(
      children: <Widget>[
        Container(
          child: ListTile(
            leading: Icon(Icons.short_text),
            title: Text("${dictation_words[index].word} - ${dictation_words[index].translation}"),
          ),
        ),
        Divider(endIndent: 20,indent: 20,color: Colors.grey,)
      ],
    );
  }
  Widget buildCard(BuildContext context, int index)
  {
    return Column(
      children: <Widget>[
        Container(
          child: ListTile(
            leading: Icon(Icons.assignment),
            title: Text("${GlobalParameters.Dictations[index].name}"),
          ),
        ),
        Divider(endIndent: 20,indent: 20,color: Colors.grey,)
      ],
    );
  }
  Widget title()
  {
    return MyHeader(
      textTop: Positioned(
          top: 10,
          left: 70,
          child: Text(
            "Add new dictation",
            style: kHeadingTextStyle.copyWith(
                color: Colors.white,
                fontSize: 30
            ),
          ),
        ),
      textBottom: Text(""),
      offset: 2,
      height: 300,
      left_height: 200,
      right_height: 80,
      color_1: Colors.lightBlue,
      color_2: Colors.lightBlue[200],
      left_widget: back_icon(),
      right_widget: Container(),
    );
//    return ClipPath(
//      clipper: MyClipper(),
//      child: Container(
//        padding: EdgeInsets.only(left: 40, top: 50, right: 20),
//        height: 300,
//        width: double.infinity,
//        decoration: BoxDecoration(
//          gradient: LinearGradient(
//            begin: Alignment.topRight,
//            end: Alignment.bottomLeft,
//            colors: [
//              Colors.lightBlue,
//              Colors.lightBlue[200],
//            ],
//          ),
////          image: DecorationImage(
////
////              alignment: Alignment.bottomLeft,
////               image: AssetImage("assets/dictation_icon.png",),//
////            ),
//
//        ),
//        child: Column(
//          children: <Widget>[
//            Row(
//              mainAxisAlignment: MainAxisAlignment.spaceBetween,
//              //crossAxisAlignment: CrossAxisAlignment.end,
//              children: <Widget>[
//                GestureDetector(
//                  onTap: () {
////                    Navigator.push(
////                      context,
////                      MaterialPageRoute(
////                        builder: (context) {
////                          return InfoScreen();
////                        },
////                      ),
////                    );
//                  },
//                  child: Container(
//
//                      child: IconButton(
//                        icon: Icon(Icons.arrow_back_ios,size:35,color: Colors.black,),
//                        onPressed: (){
//                          Navigator.pop(
//                            context,
//                            MaterialPageRoute(
//                              builder: (context) {
//                                return NewDictation();
//                              },
//                            ),
//                          );
//                        },
//                      )
//                  ),//Icon(Icons.b)//SvgPicture.asset("assets/icons/menu.svg"),
//                ),
//                GestureDetector(
//                  onTap: () {
////                    Navigator.push(
////                      context,
////                      MaterialPageRoute(
////                        builder: (context) {
////                          return InfoScreen();
////                        },
////                      ),
////                    );
//                  },
//                  child: Container(
////                      width: 30,
////                      height: 30,
////                      child: Image.asset("assets/menu_icon.png")
//                  ),//Icon(Icons.b)//SvgPicture.asset("assets/icons/menu.svg"),
//                ),
//                //SizedBox(height: 10),
//
//
//              ],
//            ),
//
//            Expanded(
//              child: Stack(
//                children: <Widget>[
////                  Positioned(
////                    top: (widget.offset < 0) ? 0 : widget.offset,
////                    child: Icon(Icons.battery_alert)
//////                    SvgPicture.asset(
//////                      widget.image,
//////                      width: 230,
//////                      fit: BoxFit.fitWidth,
//////                      alignment: Alignment.topCenter,
//////                    ),
////                  ),
//                  Positioned(
//                    top: 10,
//                    left: 70,
//                    child: Text(
//                      "${textTop} \n${textBottom}",
//                      style: kHeadingTextStyle.copyWith(
//                        color: Colors.white,
//                        fontSize: 30
//                      ),
//                    ),
//                  ),
//                  Container(), // I don't know why it can't work without container
//                ],
//              ),
//            ),
//
//          ],
//        ),
//      ),
//    );
  }
  Widget back_icon()
  {
    return IconButton(
      icon: Icon(Icons.arrow_back_ios, size: 35, color: Colors.black,),
      onPressed: () {
        Navigator.pop(
          context,
          MaterialPageRoute(
            builder: (context) {
              return NewDictation();
            },
          ),
        );
      },
    );
  }
}