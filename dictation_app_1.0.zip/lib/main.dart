import 'package:dictation_app/DictationPage/StartDictationPage.dart';
import 'package:dictation_app/Globals/GlobalParameters.dart';
import 'package:dictation_app/Globals/SettingsParameters.dart';
//import 'package:dictation_app/StartDictation/StartDictationPage.dart';
import 'package:dictation_app/my_header.dart';
import 'package:dictation_app/BottomNavigationBar/BottomNavigationBarWidget.dart';
import 'package:dictation_app/new_dictation.dart';

import 'constant.dart';
//import 'package:covid_19/widgets/counter.dart';
//import 'package:covid_19/widgets/my_header.dart';
import 'package:flutter/material.dart';
//import 'package:flutter_svg/flutter_svg.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Quizme',
      theme: ThemeData(
          scaffoldBackgroundColor: kBackgroundColor,
          fontFamily: "Poppins",
          textTheme: TextTheme(
            body1: TextStyle(color: kBodyTextColor),
          )),
      home: HomeScreen(),
    );
  }
}

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with TickerProviderStateMixin {
  final controller = ScrollController();
  double offset = 0;

  @override
  void initState() {
    List<Word> words = new List<Word>();
    words.add(Word("Dog","כלב"));
    words.add(Word("Car","חתול"));
    // TODO: implement initState
    super.initState();
    controller.addListener(onScroll);
    GlobalParameters.Dictations.add(Dictation("Animals",words,false,"Quiz only on the translations"));
    GlobalParameters.Dictations.add(Dictation("Animals",words,false,"Quiz only on the translations"));
    GlobalParameters.Dictations.add(Dictation("Animals",words,false,"Quiz only on the translations"));
    GlobalParameters.tab_controller = new TabController(vsync: this,length: 2);
    //GlobalParameters.tab_controller.addListener(_handleSelected);
  }

  @override
  void dispose() {
    // TODO: implement dispose
    controller.dispose();
    super.dispose();
  }

  void onScroll() {
    setState(() {
      offset = (controller.hasClients) ? controller.offset : 0;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: Material(
        color: Colors.grey[100],
        child: TabBar(

            indicatorColor: Colors.blueAccent,
            controller: GlobalParameters.tab_controller, tabs: <Tab>[
          Tab(icon: new Icon(Icons.home,color: Colors.grey[400],)),
          Tab(icon: new Icon(Icons.settings,color: Colors.grey[400],)),
        ]),
      ),
      body: Container(
//        decoration: BoxDecoration(
//          image: DecorationImage(
//            image: AssetImage(current_wallpaper),
//            fit: BoxFit.cover,
//          ),
//        ),
        child: new TabBarView(controller: GlobalParameters.tab_controller, children: <Widget>[
          SingleChildScrollView(
            controller: controller,
            child: Column(
              children: <Widget>[
                MyHeader(
                  image: "assets/menu_icon.png",
//                  Positioned(
//                    top: 10,
//                    left: 80,
//                    child: Text(
//                      "${widget.textTop} \n${widget.textBottom}",
//                      style: kHeadingTextStyle.copyWith(
//                          color: Colors.white,
//                          fontSize: 50,
//                          fontStyle: FontStyle.italic
//                      ),
//                    ),
//                  ),
                  textTop: Positioned(
                    top: 10,
                    left: 80,
                    child: Text(
                      "Quizme\n",
                      style: kHeadingTextStyle.copyWith(
                        color: Colors.white,
                        fontSize: 50,
                          fontStyle: FontStyle.italic
                      ),
                    ),
                  ),
                  textBottom: Positioned(
                    top: 10,
                    left: 80,
                    child: Text(
                      "",
                      style: kHeadingTextStyle.copyWith(
                          color: Colors.white,
                          fontSize: 50,
                          fontStyle: FontStyle.italic
                      ),
                    ),
                  ),
                  offset: offset,
                  height: 300,
                  left_height: 80,
                  right_height: 80,
                  color_1: Color(0xFF3383CD),
                  color_2: Color(0xFF11249F),
                  left_widget: main_left_widget(),
                  right_widget: main_right_widget(),
                ),
                Align(
                    alignment: Alignment.topLeft,
                    child: Padding(
                      padding: EdgeInsets.fromLTRB(35,10,4,4),
                      child: Text("Dictations",style: TextStyle(
                          fontSize: 20
                      ),),
                    )
                ),
                GestureDetector(
                  onTap: (){
                    //_modalBottomSheetMenu();
                    showModalBottomSheet(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(15.0),
                        ),
                        context: context,
                        builder: (context){
                          return Column(
                            mainAxisSize: MainAxisSize.min,
                            children: <Widget>[
                              ListView.builder(
                                  scrollDirection: Axis.vertical,
                                  shrinkWrap: true,
                                  itemCount: GlobalParameters.Dictations.length,
                                  itemBuilder: (BuildContext context, int index) =>
                                      bottom_item(context, index)),

//                          ListTile(
//                            leading: Icon(Icons.featured_play_list),
//                            title: Text("dictation number..."),
//                          ),
//                          ListTile(
//                            leading: Icon(Icons.featured_play_list),
//                            title: Text("dictation number..."),
//                          ),
//                          ListTile(
//                            leading: Icon(Icons.featured_play_list),
//                            title: Text("dictation number..."),
//                          )
                            ],
                          );
                        }
                    );
                  },
                  child: Container(
                    margin: EdgeInsets.symmetric(horizontal: 20),
                    padding: EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                    height: 60,
                    width: double.infinity,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(25),
                      border: Border.all(
                        color: Color(0xFFE5E5E5),
                      ),
                    ),
                    child: Row(
                      children: <Widget>[
                        Icon(Icons.featured_play_list,color: kPrimaryColor,),
                        //SvgPicture.asset("assets/icons/maps-and-flags.svg"),
                        SizedBox(width: 20),
                        Expanded(
                          //child: GestureDetector(
                          child: Text(GlobalParameters.selected_dictation),
                        ),
                        Icon(Icons.assignment,color: kTextLightColor,),
                      ],
                    ),
                  ),
                ),
                SizedBox(height: 20),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 20),
                  child: Column(
                    children: <Widget>[
                      Row(
                        children: <Widget>[
                          RichText(
                            text: TextSpan(
                              children: [
                                TextSpan(
                                  text: "Last Dictation\n",
                                  style: kTitleTextstyle,
                                ),
                                TextSpan(
                                  text: "Last Dictation was on March 28",
                                  style: TextStyle(
                                    color: kTextLightColor,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Spacer(),
                          Text(
                            "See details",
                            style: TextStyle(
                              color: kPrimaryColor,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 20),
                      Container(
                        padding: EdgeInsets.all(20),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(20),
                          color: Colors.white,
                          boxShadow: [
                            BoxShadow(
                              offset: Offset(0, 4),
                              blurRadius: 30,
                              color: kShadowColor,
                            ),
                          ],
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: <Widget>[
                          ],
                        ),
                      ),
                      SizedBox(height: 20),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                          Text(
                            "Neo",
                            style: kTitleTextstyle,
                          ),
                          Text(
                            "See details",
                            style: TextStyle(
                              color: kPrimaryColor,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                      Container(
                        margin: EdgeInsets.only(top: 20),
                        padding: EdgeInsets.all(20),
                        height: 178,
                        width: double.infinity,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(20),
                          color: Colors.white,
                          boxShadow: [
                            BoxShadow(
                              offset: Offset(0, 10),
                              blurRadius: 30,
                              color: kShadowColor,
                            ),
                          ],
                        ),
//                    child: Image.asset(
//                      "assets/images/map.png",
//                      fit: BoxFit.contain,
//                    ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          //////////////////
          //End of tab 1
          //////////////////
          SingleChildScrollView(
            child: Column(
                children: <Widget>[
                  MyHeader(
                    image: "assets/menu_icon.png",
                    textTop: Positioned(
                      top: 10,
                      left: 80,
                      child: Text(
                        "Settings\n",
                        style: kHeadingTextStyle.copyWith(
                            color: Colors.white,
                            fontSize: 50,
                            fontStyle: FontStyle.italic
                        ),
                      ),
                    ),
                    textBottom: Positioned(
                      top: 10,
                      left: 80,
                      child: Text(
                        "",
                        style: kHeadingTextStyle.copyWith(
                            color: Colors.white,
                            fontSize: 50,
                            fontStyle: FontStyle.italic
                        ),
                      ),
                    ),
                    offset: 2,
                    height: 250,
                    left_height: 30,
                    right_height: 100,
                    color_1: Colors.orange,
                    color_2: Colors.redAccent,
                    left_widget: settings_left_widget(),
                    right_widget: settings_right_widget(),
                  ),
                  Divider(
                    height: 20,
                    color: Colors.grey,
                  ),
                  RadioListTile(
                    value: 1,
                    groupValue: SettingParameters.boy_or_girl_group,
                    title: Text("Boy voice"),
                    //subtitle: Text("Radio 1 Subtitle"),
                    onChanged: (val) {
                      print("Radio Tile pressed $val");
                      //setSelectedRadioTile(val);
                      setState(() {
                        SettingParameters.boy_or_girl_group = val;
                      });
                    },
                    //activeColor: Colors.red,
                    secondary: OutlineButton(
                      child: Text("Say Hi"),
                      onPressed: () {
                        print("Say Hello");
                      },
                    ),
                    selected: false,
                  ),
                  RadioListTile(
                    value: 2,
                    groupValue: SettingParameters.boy_or_girl_group,
                    title: Text("Girl voice"),
                    //subtitle: Text("Radio 2 Subtitle"),
                    onChanged: (val) {
                      print("Radio Tile pressed $val");
                      setState(() {
                        SettingParameters.boy_or_girl_group = val;
                      });

                    },
                    //activeColor: Colors.red,
                    secondary: OutlineButton(
                      child: Text("Say Hi"),
                      onPressed: () {
                        print("Say Hello");
                      },
                    ),
                    selected: false,
                  ),
                  Divider(
                    height: 20,
                    color: Colors.grey,
                  ),
                ],
              )
          )
        ],
      ),
      )
    );

  }
  Widget main_left_widget()
  {
    return Container(

        child: IconButton(
          icon: Icon(Icons.add,size: 45,color: Colors.black,),
          onPressed: (){
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) {
                  return NewDictation();
                },
              ),
            );
          },
        )
    );
  }
  Widget main_right_widget()
  {
    return GestureDetector(
      child: Container(
          width: 30,
          height: 30,
          child: Image.asset("assets/menu_icon.png")
      ),//Icon(Icons.b)//SvgPicture.asset("assets/icons/menu.svg"),
    );
  }
  Widget settings_right_widget()
  {
    return GestureDetector(
      child: Container(
          width: 30,
          height: 30,
          child: Image.asset("assets/menu_icon.png")
      ),//Icon(Icons.b)//SvgPicture.asset("assets/icons/menu.svg"),
    );
  }
  Widget settings_left_widget()
  {
    return Container(

//        child: IconButton(
//          icon: Icon(Icons.menu,size: 45,color: Colors.black,),
//          onPressed: (){
//            Navigator.push(
//              context,
//              MaterialPageRoute(
//                builder: (context) {
//                  return NewDictation();
//                },
//              ),
//            );
//          },
//        )
    );
  }
  Widget bottom_item(BuildContext context, int index)
  {
    return ListTile(
      leading: Icon(Icons.featured_play_list),
      title: Text(GlobalParameters.Dictations[index].name),
      onTap: (){
        setState(() {
          GlobalParameters.selected_dictation = GlobalParameters.Dictations[index].name;
          Navigator.pop(context);

          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) {
                return DictationInfo(GlobalParameters.Dictations[index]);
              },
            ),
          );

          //
        });

      },
    );
  }
  void _modalBottomSheetMenu(){
    showModalBottomSheet(
        context: context,
        builder: (builder){
          return new Container(
            height: 350.0,
            color: Colors.transparent, //could change this to Color(0xFF737373),
            //so you don't have to change MaterialApp canvasColor
            child: new Container(
                decoration: new BoxDecoration(
                    color: Colors.white,
                    borderRadius: new BorderRadius.only(
                        topLeft: const Radius.circular(10.0),
                        topRight: const Radius.circular(10.0))),
                child: new Center(
                  child: new Text("This is a modal sheet"),
                )),
          );
        }
    );
  }
}