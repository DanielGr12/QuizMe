import 'package:dictation_app/Animation/FadeAnimation.dart';
import 'package:dictation_app/DictationPage/DictationQuiz.dart';
//import 'package:dictation_app/DictationPage/DictationSettings.dart';
import 'package:dictation_app/Globals/GlobalParameters.dart';
import 'package:dictation_app/constant.dart';
import 'package:dictation_app/info_screen.dart';
import 'package:dictation_app/my_header.dart';
import 'package:flutter/material.dart';
import 'package:flutter/material.dart';
class DictationInfo extends StatefulWidget {
  Dictation dictation;
  DictationInfo(this.dictation);
  @override
  _DictationInfoState createState() => _DictationInfoState();
}

class _DictationInfoState extends State<DictationInfo> {
  var scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        key: scaffoldKey,
        endDrawer: settings_drawer(),
        backgroundColor: Colors.white,
        body: SingleChildScrollView(
          child: Container(
            child: Column(
              children: <Widget>[
                title("Dictation info:", widget.dictation.name),
                Container(
                  margin: EdgeInsets.symmetric(horizontal: 20),
                  padding: EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                  height: 300,
                  width: double.infinity,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(25),
                    border: Border.all(
                      color: Colors.grey[500],//Color(0xFFE5E5E5),
                    ),
                  ),
                  child: Column(
                    children: <Widget>[
                      Row(
                        children: <Widget>[
                          Padding(
                            padding: EdgeInsets.fromLTRB(25, 10, 4, 4),
                            child: Text("Words", style: TextStyle(
                                fontSize: 20
                            ),),
                          ),
                        ],
                      ),

                      Expanded(
                        child: ListView.builder(
                            scrollDirection: Axis.vertical,
                            shrinkWrap: true,
                            itemCount: GlobalParameters.Dictations.length,
                            itemBuilder: (BuildContext context, int index) =>
                                buildCard(context, index)),
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: EdgeInsets.all(15),
                ),
                Column(
                    children: <Widget>[
                      Padding(
                        padding: EdgeInsets.fromLTRB(50, 0, 50, 0),
                        child: RaisedButton(
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) {
                                  return DictationQuiz(widget.dictation);
                                },
                              ),
                            );
                          },
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(80.0)),
                          padding: const EdgeInsets.all(0.0),
                          child: Ink(
                            decoration: const BoxDecoration(
                              gradient:  LinearGradient(
                                colors: <Color>[
                                  Colors.orange,
                                  //Color(0xFF1976D2),
                                  kInfectedColor,
                                ],
                              ),
                              borderRadius: BorderRadius.all(Radius.circular(80.0)),
                            ),
                            child: Container(
                              constraints: const BoxConstraints(minWidth: 88.0, minHeight: 36.0), // min sizes for Material buttons
                              alignment: Alignment.center,
                              child: const Text(
                                'Start dictation',
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  fontSize: 17
                                ),
                              ),
                            ),
                          ),
                        ),
                      )

                    ],
                  ),

                Padding(
                  padding: EdgeInsets.all(15),
                ),
              ],
            ),
          ),
        )
    );
  }
  Widget settings_drawer() {
    return new Drawer(
      child: new ListView(
        children: <Widget>[
          Padding(
            padding: EdgeInsets.all(15),
          ),
//          new UserAccountsDrawerHeader(
//            accountName: new Text("Profile name"),
//            accountEmail: new Text("Profile Email"),
//            currentAccountPicture: new CircleAvatar(
//              backgroundColor: Colors.white,
//              child: new Icon(Icons.account_circle, size: 60),
//            ),
//          ),
          SwitchListTile(
            title: Text('Say word',
                style: TextStyle(
//                  fontSize: 20.0,
//                  fontWeight: FontWeight.bold,
                )
            ),
            subtitle: Text('The system will say the shown word',
                style: TextStyle(
//                  fontSize: 20.0,
//                  fontWeight: FontWeight.bold,
                )
            ),
            secondary: Icon(Icons.volume_up),
            value: widget.dictation.say_word,
            onChanged: (value) {
              setState(() {
                widget.dictation.say_word = value;
              });
            },
            dense: true,
          ),
          new Divider(color: kTextLightColor,),
          DropdownButton<String>(
            //value: widget.dictation.test_type,
            hint: Text(widget.dictation.test_type),
            items: <String>["Quiz only on the translations", "Quiz only on the words", "Quiz on both"].map((String value) {
              return new DropdownMenuItem<String>(
                value: value,
                child: new Text(value),
              );
            }).toList(),

            onChanged: (newValue) {
              setState(() {
                widget.dictation.test_type = newValue;
                //widget.dictation.test_on = val;
              });
            },
          ),
          Padding(
            padding: EdgeInsets.all(8),
          ),
          new Divider(color: kTextLightColor,),
          new ListTile(
            title: new Text("Close"),
            trailing: new Icon(Icons.close),
            onTap: () {
              setState(() {
                //LogEvent.LogEvents.clear();
              });
              Navigator.of(context).pop();
            },
          )
        ],
      ),
    );
  }
//  void change_val(String value)
//  {
//    switch(value)
//    {
//      case "Quiz only on the translations":
//        {
//          widget.dictation.test_on = quiz_variations.only_translation;
//        }
//        break;
//      case "Quiz only on the words":
//        {
//          widget.dictation.test_on = quiz_variations.only_words;
//        }
//        break;
//      case "Quiz on both":
//        {
//          widget.dictation.test_on = quiz_variations.both;
//        }
//        break;
//    }
//  }
//  String getStringFromEnum(quiz_variations quiz) {
//    switch (quiz) {
//      case quiz_variations.only_translation: return "Quiz only on the translations";
//      case quiz_variations.only_words: return "Quiz only on the words";
//      case quiz_variations.both: return "Quiz on both";
//    }
//    return "Quiz only on the translations";
//  }
//  Widget hint_val()
//  {
//    switch(quiz_variations)
//    {
//      case quiz_variations.only_translation:
//        {
//          return Text("Quiz only on the translations");
//        }
//        break;
//      case quiz_variations.only_words:
//        {
//          return Text("Quiz only on the words");
//        }
//        break;
//      case quiz_variations.both:
//        {
//          return Text("Quiz on both");
//        }
//        break;
//    }
//    return Text("Quiz only on the translations");
//  }
  Widget buildCard(BuildContext context, int index)
  {
    if (index != widget.dictation.words_list.length)
      {
        return Column(
          children: <Widget>[
            Container(
              child: ListTile(
                leading: Icon(Icons.short_text),
                title: Text("${widget.dictation.words_list[index].word} - ${widget.dictation.words_list[index].translation}"),
              ),
            ),
            Divider(endIndent: 20,indent: 20,color: Colors.grey,)
          ],
        );
      }
    return SizedBox.shrink();
  }
  Widget title(String textTop, String textBottom)
  {
    return ClipPath(
      clipper: MyClipper(),
      child: Container(
        padding: EdgeInsets.only(left: 40, top: 50, right: 20),
        height: 300,
        width: double.infinity,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topRight,
            end: Alignment.bottomLeft,
            colors: [
              Colors.orange,
              Colors.orangeAccent[100],
            ],
          ),
        ),
        child: Column(
          children: <Widget>[
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              //crossAxisAlignment: CrossAxisAlignment.end,
              children: <Widget>[
                GestureDetector(
                  onTap: () {
                  },
                  child: Container(

                      child: IconButton(
                        icon: Icon(Icons.arrow_back_ios,size:35,color: Colors.black,),
                        onPressed: (){
                          Navigator.pop(
                            context,
                            MaterialPageRoute(
                              builder: (context) {
                                return DictationInfo(widget.dictation);
                              },
                            ),
                          );
                        },
                      )
                  ),//Icon(Icons.b)//SvgPicture.asset("assets/icons/menu.svg"),
                ),
                GestureDetector(
                  onTap: () {
                  },
                  child: IconButton(
                    icon: Icon(Icons.settings),
                    onPressed: (){
                      scaffoldKey.currentState.openEndDrawer();
                    },
                  )//SvgPicture.asset("assets/icons/menu.svg"),
                ),
                //SizedBox(height: 10),


              ],
            ),

            Expanded(
              child: Stack(
                children: <Widget>[
//                  Positioned(
//                    top: (widget.offset < 0) ? 0 : widget.offset,
//                    child: Icon(Icons.battery_alert)
////                    SvgPicture.asset(
////                      widget.image,
////                      width: 230,
////                      fit: BoxFit.fitWidth,
////                      alignment: Alignment.topCenter,
////                    ),
//                  ),
                  Positioned(
                    //top: 10,
                    left: 100,
                    child: Text(
                      "${textTop} \n\n          ${textBottom}",
                      style: kHeadingTextStyle.copyWith(
                        color: Colors.white,
                        fontSize: 30
                      ),
                    ),
                  ),
                  Container(), // I don't know why it can't work without container
                ],
              ),
            ),

          ],
        ),
      ),
    );
  }
}
class MyClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    var path = Path();
    path.lineTo(0, size.height - 200);
    path.quadraticBezierTo(
        size.width / 2, size.height, size.width, size.height - 80);
    path.lineTo(size.width, 0);
    path.close();
    return path;
  }

  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) {
    return false;
  }}