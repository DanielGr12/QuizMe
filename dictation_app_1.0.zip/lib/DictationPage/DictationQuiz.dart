import 'dart:math';

import 'package:dictation_app/Globals/GlobalParameters.dart';
import 'package:dictation_app/constant.dart';
import 'package:dictation_app/my_header.dart';
import 'package:flutter/material.dart';

class DictationQuiz extends StatefulWidget {
  Dictation dictation;
  DictationQuiz(this.dictation);
  @override
  _DictationQuizState createState() => _DictationQuizState();
}

class _DictationQuizState extends State<DictationQuiz> {
  String user_text_val;
  var _controller = TextEditingController();
  String submit_button_text = "Submit";
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: <Widget>[
            MyHeader(
              image: "",
              textTop: Positioned(
                //top: 10,
                left: 100,
                child: Text(
                  "Quiz\n",
                  style: kHeadingTextStyle.copyWith(
                      color: Colors.white,
                      fontSize: 50,
                      fontStyle: FontStyle.italic
                  ),
                ),
              ),
              textBottom: Positioned(
                //top: 10,
                left: 50,
                child: Text(
                  "\n\nWord ${GlobalParameters.tested_words_count+1} out of ${widget.dictation.words_list.length}",
                  style: kHeadingTextStyle.copyWith(
                      color: Colors.white,
                      fontSize: 25,
                      fontStyle: FontStyle.italic
                  ),
                ),
              ),
              offset: 2,
              height: 250,
              left_height: 30,
              right_height: 100,
              color_1: Colors.orange,
              color_2: Colors.redAccent,
              left_widget: quiz_left_widget(),
              right_widget: Container(),
            ),
            word_generator(),
            Divider(
              color: Colors.grey,
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20,0,20,15),
              child: TextFormField(
                controller: _controller,
                decoration: InputDecoration(
                  labelText: "Translation",
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                ),
                onChanged: (String val){
                  user_text_val = val;
                },
                onFieldSubmitted: (String translation){
                  //GlobalParameters.tested_words.add(translation);
                },
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: <Widget>[
                 custom_button(submit_button_text,on_submitted),
                 custom_button("Skip",on_submitted),
            ],)
          ],
        ),
      ),
    );
  }
  void on_skip()
  {
    GlobalParameters.tested_words.add("skipped");
    _controller.clear();
    GlobalParameters.tested_words_count++;
  }
  void on_submitted()
  {
    if (GlobalParameters.tested_words_count == widget.dictation.words_list.length-1)
      {
        setState(() {
          //TODO: Finish text don't show up: FIX
          submit_button_text = "Finish";
        });

        //TODO: add check answers page
      }
    else
      {
        setState(() {
          _controller.clear();
          GlobalParameters.tested_words_count++;
          if (user_text_val == null)
              GlobalParameters.tested_words.add("");
          else
              GlobalParameters.tested_words.add(user_text_val);
        });
      }


  }
  Widget custom_button(String text,Function on_pressed)
  {
    return RaisedButton(
      onPressed: () {
        on_pressed();
//        Navigator.push(
//          context,
//          MaterialPageRoute(
//            builder: (context) {
//              return DictationQuiz(widget.dictation);
//            },
//          ),
//        );
      },
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(80.0)),
      padding: const EdgeInsets.all(0.0),
      child: Ink(
        decoration: const BoxDecoration(
          gradient:  LinearGradient(
            colors: <Color>[
              Colors.orange,
              //Color(0xFF1976D2),
              kInfectedColor,
            ],
          ),
          borderRadius: BorderRadius.all(Radius.circular(80.0)),
        ),
        child: Container(
          constraints: const BoxConstraints(minWidth: 88.0, minHeight: 36.0), // min sizes for Material buttons
          alignment: Alignment.center,
          child: Text(
            text,
            textAlign: TextAlign.center,
            style: TextStyle(
                fontSize: 17
            ),
          ),
        ),
      ),
    );
  }
  Widget word_generator()
  {
    String returned_word;
    switch (widget.dictation.test_type) {
      case "Quiz only on the translations":
        {
          returned_word = "${widget.dictation.words_list[GlobalParameters.tested_words_count].translation}";
        }
        break;
      case "Quiz only on the words":
        {
          returned_word = "${widget.dictation.words_list[GlobalParameters.tested_words_count].word}";
        }
        break;
      case "Quiz on both":
        {
          var rng = new Random();
          int random_number = rng.nextInt(2);
          if (random_number == 1)
            {
              returned_word = "${widget.dictation.words_list[GlobalParameters.tested_words_count].word}";
            }
          else
            {
              returned_word = "${widget.dictation.words_list[GlobalParameters.tested_words_count].translation}";
            }
        }
        break;
    }
    return Text(
      returned_word,
      style: TextStyle(
          fontSize: 35
      ),
    );

  }
  Widget quiz_left_widget()
  {
    return Container(
      child: IconButton(
        icon: Icon(Icons.clear,size: 40,),
        onPressed: (){
          Navigator.pop(context);
        },
      ),
    );
  }
}