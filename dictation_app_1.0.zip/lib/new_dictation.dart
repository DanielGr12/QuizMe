import 'package:dictation_app/Animation/FadeAnimation.dart';
import 'package:dictation_app/Globals/GlobalParameters.dart';
import 'package:dictation_app/constant.dart';
import 'package:dictation_app/my_header.dart';
import 'package:flutter/material.dart';
class NewDictation extends StatefulWidget {
  @override
  _NewDictationState createState() => _NewDictationState();
}

class _NewDictationState extends State<NewDictation> {
  final List<Map<String, String>> listOfColumns = [
    { "Number": "1", "State": "Yes"},
    { "Number": "2", "State": "no"},
    { "Number": "3", "State": "Yes"}
  ];
  final List<Map<String, Widget>> Rows = [
    { "Number": TextField(), "State": TextField()},
    { "Number": TextField(), "State": TextField()},
    { "Number": TextField(), "State": TextField()}
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.white,
        body: SingleChildScrollView(
          child: Container(
            child: Column(
              children: <Widget>[
                title("Add new dictation", ""),
//                MyHeader(
//                  image: "assets/menu_icon.png",
//                  textTop: "Add new dictation",
//                  textBottom: "",
//                  offset: 20,
//                ),
              Padding(
                padding: const EdgeInsets.fromLTRB(20,0,20,15),
                child: TextFormField(
                  decoration: InputDecoration(
                    labelText: "Name",
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                  ),
                  onFieldSubmitted: (String dictation_name){
                    GlobalParameters.add_words.name = dictation_name;
                  },
                ),
              ),
                Container(
                  margin: EdgeInsets.symmetric(horizontal: 20),
                  padding: EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                  height: 200,
                  width: double.infinity,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(25),
                    border: Border.all(
                      color: Colors.grey[500],//Color(0xFFE5E5E5),
                    ),
                  ),
                  child: Column(
                    children: <Widget>[
                      Row(
                        children: <Widget>[
                          Padding(
                            padding: EdgeInsets.fromLTRB(25, 10, 4, 4),
                            child: Text("Words", style: TextStyle(
                                fontSize: 20
                            ),),
                          ),
                          Spacer(),
                          IconButton(
                              icon: Icon(Icons.add),
                            onPressed: (){
                              showDialog(
                                  context: context,
                                  builder: (BuildContext context){
                                    return StatefulBuilder(
                                      builder: (context, setState)
                                      {
                                        return AlertDialog(
                                          //titlePadding: EdgeInsets.all(0),
                                            shape: new RoundedRectangleBorder(
                                              borderRadius: new BorderRadius.circular(20),
                                            ),//+ Border.all(color: Colors.white),///contentPadding: EdgeInsets.all(0.0),
                                            title: Container(
                                                child: Text("Add word",style: TextStyle(fontSize: 25,fontWeight: FontWeight.bold),)
                                            ),
                                            content: SingleChildScrollView(
                                              child: Column(
                                                children: <Widget>[
                                                  Row(
                                                    mainAxisAlignment: MainAxisAlignment.end,
                                                    children: <Widget>[
                                                      IconButton(
                                                        icon: Icon(Icons.add),
                                                        onPressed: (){
                                                          setState(() {
                                                            Rows.add({"Number": TextField(), "State": TextField()});
                                                            //listOfColumns.add({"Number": "1", "State": "Yes"} );
                                                          });
                                                        },
                                                      )
                                                    ],
                                                  ),
                                                  DataTable(
                                                    columns: <DataColumn>[

                                                      DataColumn(
                                                        label:
                                                        Text(
                                                          'Word',
                                                          style: TextStyle(
                                                              fontStyle: FontStyle
                                                                  .italic),
                                                        ),
                                                      ),
                                                      DataColumn(
                                                        label: Text(
                                                          'Translation',
                                                          style: TextStyle(
                                                              fontStyle: FontStyle
                                                                  .italic),
                                                        ),
                                                      ),
                                                    ],
                                                    rows:
                                                    Rows // Loops through dataColumnText, each iteration assigning the value to element
                                                        .map(
                                                      ((element) => DataRow(
                                                        cells: <DataCell>[
                                                          //DataCell(Text(element["Name"])), //Extracting from Map element the value
                                                          DataCell(Container(
                                                            child: element["Number"],
                                                          )),
                                                          DataCell(element["State"]),
                                                        ],
                                                      )),
                                                    )
                                                        .toList(),
//                                              DataRow(
//                                                cells: <DataCell>[
//                                                  DataCell(Text('Tran')),
//                                                  DataCell(Text('43')),
//                                                  DataCell(Text('Professor')),
//                                                ],
//                                              ),
//                                              DataRow(
//                                                cells: <DataCell>[
//                                                  DataCell(Text('William')),
//                                                  DataCell(Text('27')),
//                                                  DataCell(Text(
//                                                      'Associate Professor')),
//                                                ],
//                                              ),

                                                  ),
                                                ],
                                              ),
                                            )
                                        );
                                      },
                                    );

                                  }

                              );
                            },
                          ),
                        ],
                      ),

                      GlobalParameters.add_words != null ? Expanded(
                        child: ListView.builder(
                            scrollDirection: Axis.vertical,
                            shrinkWrap: true,
                            itemCount: GlobalParameters.add_words.words_list.length,
                            itemBuilder: (BuildContext context, int index) =>
                                buildCard(context, index)),
                      ): SizedBox.shrink(),

                    ],
                  ),
                ),
                Padding(
                  padding: EdgeInsets.all(15),
                ),
              Container(
                margin: EdgeInsets.symmetric(horizontal: 20),
                padding: EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                height: 200,
                width: double.infinity,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(25),
                  border: Border.all(
                    color: Colors.grey[500],//Color(0xFFE5E5E5),
                  ),
                ),
                child: Column(
                  children: <Widget>[
                    Align(
                        alignment: Alignment.topLeft,
                        child: Padding(
                          padding: EdgeInsets.fromLTRB(25,10,4,4),
                          child: Text("Existing dictations",style: TextStyle(
                              fontSize: 20
                          ),),
                        )
                    ),

                    Expanded(
                      child: ListView.builder(
                            scrollDirection: Axis.vertical,
                            shrinkWrap: true,
                            itemCount: GlobalParameters.Dictations.length,
                            itemBuilder: (BuildContext context, int index) =>
                                buildCard(context, index)),
                    ),

                  ],
                ),
              ),
                Padding(
                  padding: EdgeInsets.all(15),
                ),
              ],
            ),
          ),
        )
    );
  }
  Widget buildCard(BuildContext context, int index)
  {

    return Column(
      children: <Widget>[
        Container(
          child: ListTile(
            leading: Icon(Icons.assignment),
            title: Text("${GlobalParameters.Dictations[index].name}"),
          ),
        ),
        Divider(endIndent: 20,indent: 20,color: Colors.grey,)
      ],
    );
  }
  Widget title(String textTop, String textBottom)
  {
    return ClipPath(
      clipper: MyClipper(),
      child: Container(
        padding: EdgeInsets.only(left: 40, top: 50, right: 20),
        height: 300,
        width: double.infinity,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topRight,
            end: Alignment.bottomLeft,
            colors: [
              Colors.lightBlue,
              Colors.lightBlue[200],
            ],
          ),
//          image: DecorationImage(
//
//              alignment: Alignment.bottomLeft,
//               image: AssetImage("assets/dictation_icon.png",),//
//            ),

        ),
        child: Column(
          children: <Widget>[
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              //crossAxisAlignment: CrossAxisAlignment.end,
              children: <Widget>[
                GestureDetector(
                  onTap: () {
//                    Navigator.push(
//                      context,
//                      MaterialPageRoute(
//                        builder: (context) {
//                          return InfoScreen();
//                        },
//                      ),
//                    );
                  },
                  child: Container(

                      child: IconButton(
                        icon: Icon(Icons.arrow_back_ios,size:35,color: Colors.black,),
                        onPressed: (){
                          Navigator.pop(
                            context,
                            MaterialPageRoute(
                              builder: (context) {
                                return NewDictation();
                              },
                            ),
                          );
                        },
                      )
                  ),//Icon(Icons.b)//SvgPicture.asset("assets/icons/menu.svg"),
                ),
                GestureDetector(
                  onTap: () {
//                    Navigator.push(
//                      context,
//                      MaterialPageRoute(
//                        builder: (context) {
//                          return InfoScreen();
//                        },
//                      ),
//                    );
                  },
                  child: Container(
                      width: 30,
                      height: 30,
                      child: Image.asset("assets/menu_icon.png")
                  ),//Icon(Icons.b)//SvgPicture.asset("assets/icons/menu.svg"),
                ),
                //SizedBox(height: 10),


              ],
            ),

            Expanded(
              child: Stack(
                children: <Widget>[
//                  Positioned(
//                    top: (widget.offset < 0) ? 0 : widget.offset,
//                    child: Icon(Icons.battery_alert)
////                    SvgPicture.asset(
////                      widget.image,
////                      width: 230,
////                      fit: BoxFit.fitWidth,
////                      alignment: Alignment.topCenter,
////                    ),
//                  ),
                  Positioned(
                    top: 10,
                    left: 70,
                    child: Text(
                      "${textTop} \n${textBottom}",
                      style: kHeadingTextStyle.copyWith(
                        color: Colors.white,
                        fontSize: 30
                      ),
                    ),
                  ),
                  Container(), // I don't know why it can't work without container
                ],
              ),
            ),

          ],
        ),
      ),
    );
  }
}
class MyClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    var path = Path();
    path.lineTo(0, size.height - 200);
    path.quadraticBezierTo(
        size.width / 2, size.height, size.width, size.height - 80);
    path.lineTo(size.width, 0);
    path.close();
    return path;
  }

  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) {
    return false;
  }}