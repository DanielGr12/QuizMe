class SettingParameters
{
  static String boy_or_girl_voice = "girl";
  static int boy_or_girl_group;
}