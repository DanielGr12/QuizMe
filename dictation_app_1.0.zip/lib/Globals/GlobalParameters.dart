import 'package:flutter/material.dart';
class GlobalParameters
{

  static List<Dictation> Dictations = new List<Dictation>();
  static Dictation add_words;
  static List<DropdownMenuItem<String>> languages_list = new List<DropdownMenuItem<String>>();
  static String selected_dictation = "Select dictation";
  static TabController tab_controller;
  static int tested_words_count = 0;
  static List<String> tested_words = new List<String>();


}
class Dictation
{
  String name;
  List<Word> words_list = new List<Word>();
  bool say_word = false;
  String test_type;
  Dictation(this.name,this.words_list,this.say_word,this.test_type);
}
class Word
{
  String word;
  String translation;
  Word(this.word,this.translation);
}